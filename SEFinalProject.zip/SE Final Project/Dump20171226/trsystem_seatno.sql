-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: trsystem
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `seatno`
--

DROP TABLE IF EXISTS `seatno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seatno` (
  `seatID` int(11) NOT NULL AUTO_INCREMENT,
  `A` varchar(45) DEFAULT NULL,
  `B` varchar(45) DEFAULT NULL,
  `C` varchar(45) DEFAULT NULL,
  `D` varchar(45) DEFAULT NULL,
  `SID` int(11) NOT NULL,
  PRIMARY KEY (`seatID`),
  KEY `SID` (`SID`),
  CONSTRAINT `seatno_ibfk_1` FOREIGN KEY (`SID`) REFERENCES `stadium` (`StID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seatno`
--

LOCK TABLES `seatno` WRITE;
/*!40000 ALTER TABLE `seatno` DISABLE KEYS */;
INSERT INTO `seatno` VALUES (1,'A1','B1','C1','D1',1),(2,'A2','B2','C2','D2',1),(3,'A3','B3','C3','D3',1),(4,'A4','B4','C4','D4',1),(5,'A5','B5','C5','D5',1),(6,'A6','B6','C6','D6',1),(7,'A7','B7','C7','D7',1),(8,'A8','B8','C8','D8',1),(9,'A9','B9','C9','D9',1),(10,'A10','B10','C10','D10',1),(11,'A11','B11','C11','D11',1),(12,'A12','B12','C12','D12',1),(13,'A13','B13','C13','D13',1),(14,'A14','B14','C14','D14',1),(15,'A15','B15','C15','D15',1),(16,'A16','B16','C16','D16',1),(17,'A17','B17','C17','D17',1),(18,'A18','B18','C18','D18',1),(19,'A19','B19','C19','D19',1),(20,'A20','B20','C20','D20',1),(21,'A1','B1','C1','D1',2),(22,'A2','B2','C2','D2',2),(23,'A3','B3','C3','D3',2),(24,'A4','B4','C4','D4',2),(25,'A5','B5','C5','D5',2),(26,'A6','B6','C6','D6',2),(27,'A7','B7','C7','D7',2),(28,'A8','B8','C8','D8',2),(29,'A9','B9','C9','D9',2),(30,'A10','B10','C10','D10',2),(31,'A11','B11','C11','D11',2),(32,'A12','B12','C12','D12',2),(33,'A13','B13','C13','D13',2),(34,'A14','B14','C14','D14',2),(35,'A15','B15','C15','D15',2),(36,'A16','B16','C16','D16',2),(37,'A17','B17','C17','D17',2),(38,'A18','B18','C18','D18',2),(39,'A19','B19','C19','D19',2),(40,'A20','B20','C20','D20',2);
/*!40000 ALTER TABLE `seatno` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-26 21:54:23
